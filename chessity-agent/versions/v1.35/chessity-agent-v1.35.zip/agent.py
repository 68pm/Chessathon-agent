"""Chessathon agent: original compiled search; all learning happens offline."""

import json
import os
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
for _name in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMBA_NUM_THREADS']:
    os.environ[_name] = '1'

import chess
from engine.compiled_driver import CompiledSearch

from engine.openings import alien_move
from engine.player_policy import PlayerPolicy
from engine.time_manager import allocate

_root = Path(__file__).resolve().parent
_config = json.loads((_root / 'runtime.json').read_text())
_opening = alien_move
_policy = PlayerPolicy(_root / 'models/player-policy.npz') if _config.get('player_policy') else None
_search = CompiledSearch(_policy, _config.get('policy_cp', 10),
                         conversion=_config.get('conversion', False),
                         reductions=_config.get('reductions', False),
                         model=_root / 'models/value.npz' if _config.get('residual_value') else None,
                         blend=_config.get('value_blend', 0.0))
_search.warmup()
_last = None


def get_move(fen: str, time_left_ms: int) -> str:
    global _last
    started = time.perf_counter()
    board = chess.Board(fen)
    fallback = next(iter(board.legal_moves), None)
    if fallback is None:
        return '0000'
    if time_left_ms <= 20:
        return fallback.uci()
    if _last is not None:
        for move in list(_last.legal_moves):
            _last.push(move)
            if _last.fen() == fen:
                board = _last.copy(stack=True)
                _last.pop()
                break
            _last.pop()
    budget = allocate(time_left_ms, board.fullmove_number, board.legal_moves.count())
    overhead = time.perf_counter() - started
    preferred = alien_move(board) if _config.get('opening_style') == 'alien-selective' else None
    result = _search.run(board, max(0, budget.hard - overhead), max(0, budget.soft - overhead),
                         preferred_move=preferred, preference_cp=_config.get('alien_cp', 15))
    chosen = result.move if result.move in board.legal_moves else fallback
    board.push(chosen)
    _last = board
    return chosen.uci()
